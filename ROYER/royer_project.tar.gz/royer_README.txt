Royer 推挽动画工程
================

成品
- power_history/royer_animation.mp4  主动画（1920x1080, 60fps, 26s）
- power_history/royer_topology.png   拓扑静帧

源码（Python + cairo）
- circ/symbols.py        可复用符号：导线、电阻、线圈、变压器、NPN、GND、电流、磁通环等
- circ/royer_anim.py     Royer 动画场景
- circ/royer_topology.py 拓扑静帧生成

重渲染（需本机已有 /workspace/ve 或自行安装 pycairo、ffmpeg）
  /workspace/ve/bin/python circ/royer_anim.py
  /workspace/ve/bin/python circ/royer_topology.py
